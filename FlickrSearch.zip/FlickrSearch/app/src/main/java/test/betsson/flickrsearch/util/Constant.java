package test.betsson.flickrsearch.util;

/**
 * Created by suresh.kumar on 2015-02-10.
 */
public class Constant {

	public static final String INTENT_EXTRA_RESULT_CODE = "resultCode";
	public static final int INTENT_EXTRA_RESULT_SUCCESS = 200;
	public static final int INTENT_EXTRA_RESULT_FAILED = 8001;
}
